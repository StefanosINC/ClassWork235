package beans;

import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;




@ManagedBean
public class Orders {

	List<Order> orders = new ArrayList<Order>();
	
	public Orders() {
		
		orders.add(new Order("00000001", "This is the product 1", (float)11.90, 1));
		
		orders.add(new Order("00000002", "This is the product 2", (float)15.10, 2));
		orders.add(new Order("00000003", "This is the product 3", (float)16.70, 3));
		orders.add(new Order("00000004", "This is the product 4", (float)18.10, 4));
		orders.add(new Order("00000005", "This is the product 5", (float)12.20, 55));
		orders.add(new Order("00000006", "This is the product 6", (float)9.03, 66));
	}

	public List<Order> getOrders() {
		return orders;
	}

	public void setOrders(List<Order> orders) {
		this.orders = orders;
	}
	
}
