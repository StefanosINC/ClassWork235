package controllers;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import beans.User;

@ManagedBean
@ViewScoped
public class formController {

	public String onSubmit() {
		// Get the user Managed Bean
		FacesContext context = FacesContext.getCurrentInstance();
		User user = context.getApplication().evaluateExpressionGet(context, "#{user}", User.class);
		
		//Forward to Test response view along with the User managed bean
		FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("user", user);
		
		return "Response.xhtml";
	}
	public String onSumbit(User user) {
	FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("user", user);
	return "Response.xhtml";
}
	
}