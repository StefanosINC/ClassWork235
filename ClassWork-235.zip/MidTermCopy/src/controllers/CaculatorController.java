package controllers;
import javax.faces.bean.ManagedBean;

import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import beans.CaculatorModel;

@ManagedBean
@ViewScoped
public class CaculatorController {
	public String onSubmit() 
	{
		FacesContext context = FacesContext.getCurrentInstance();
		CaculatorModel cac = context.getApplication().evaluateExpressionGet(context,"#{cac}", CaculatorModel.class);
		
		FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("cac", cac);
		return "NewFile.xhtml";
	}
	
	public String onSubmit(CaculatorModel cac)
	{
	FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("cac", cac);
	return "NewFile.xhtml";
	}
	public String onFlash()
	{
		FacesContext context = FacesContext.getCurrentInstance();
		CaculatorModel cac = context.getApplication().evaluateExpressionGet(context, "#{cac}", CaculatorModel.class);
		
		FacesContext.getCurrentInstance().getExternalContext().getFlash().put("cac", cac);
		return "NewFile.xhtml?faces-redirect=true";
	}
	public String onFlash(CaculatorModel cac) {
		FacesContext.getCurrentInstance().getExternalContext().getFlash().put("cac", cac);
		return "NewFile2.xhtml?faces-redirect=true";
	}
	
}
