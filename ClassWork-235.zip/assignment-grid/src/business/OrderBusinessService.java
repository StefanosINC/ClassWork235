package business;


import java.util.ArrayList;
import java.util.List;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.enterprise.inject.Alternative;

import beans.Order;




@Local(OrderBusinessInterface.class)
@Stateless
@Alternative
public class OrderBusinessService implements OrderBusinessInterface {
	

	
	  List <Order> orders = new ArrayList<Order>();
		
			 

	public OrderBusinessService() {

	
		orders.add(new Order("00000001", "This is the product 1 From OrderBusinessService", (float)11.90, 1));
		orders.add(new Order("00000002", "This is the product 2 From OrderBusinessService", (float)15.10, 2));
		orders.add(new Order("00000003", "This is the product 3 From OrderBusinessService", (float)16.70, 3));
		orders.add(new Order("00000004", "This is the product 4 From OrderBusinessService", (float)18.10, 4));
		orders.add(new Order("00000005", "This is the product 5 From OrderBusinessService", (float)12.20, 55));
		orders.add(new Order("00000006", "This is the product 6 From OrderBusinessService", (float)9.03, 66));
	}
	
	@Override
	public void test() {
		System.out.println("========= Hello from the test method . Order Business Service Version #1");
		
		
		
	}
	
	@Override
	public List<Order> getOrders() {
		// TODO Auto-generated method stub
		return orders;
	}

	@Override
	public void setOrders(List<Order> orders) {
		this.orders = orders;
		
	}

}
