package controllers;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;

import beans.User;
//import business.MyTimerService;
import business.OrderBusinessInterface;

@ManagedBean
@ViewScoped
public class formController {

	@Inject
	OrderBusinessInterface service;
	
	@EJB 
	//MyTimerService timer;
	
	
	
	public String onSubmit() {
		// Get the user Managed Bean
		FacesContext context = FacesContext.getCurrentInstance();
		User user = context.getApplication().evaluateExpressionGet(context, "#{user}", User.class);
		
		
		// prints a message to console to inform which business service is used in beans.xml file
		service.test();
		
		// Start a timer when the login is clicked
	//	timer.setTimer(10000);
		
		//Forward to Test response view along with the User managed bean
		FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("user", user);
		
		return "Response.xhtml";
	}
	public String onSumbit(User user) {
	FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("user", user);
	return "Response.xhtml";
}
	public OrderBusinessInterface getService() {
		return service;
		
	}
}