package CaculatorPackage;

import javax.faces.event.ActionEvent;

public class Caculator {

	
	private int number1;
	private int number2;
	private int AddTotal;
	private int MultiplyTotal;
	private int DivisionTotal;
	private int SubTotal;
	
	
	
// create an instance of caculator
	
	public Caculator() {
	}

	
	// Getters and Setters

	public int getNumber1() {
		return number1;
	}


	public void setNumber1(int number1) {
		this.number1 = number1;
	}


	public int getNumber2() {
		return number2;
	}


	public void setNumber2(int number2) {
		this.number2 = number2;
	}


	public int getAddTotal() {
		return AddTotal;
	}


	public void setAddTotal(int addTotal) {
		AddTotal = addTotal;
	}


	public int getMultiplyTotal() {
		return MultiplyTotal;
	}


	public void setMultiplyTotal(int multiplyTotal) {
		MultiplyTotal = multiplyTotal;
	}


	public int getDivisionTotal() {
		return DivisionTotal;
	}


	public void setDivisionTotal(int divisionTotal) {
		DivisionTotal = divisionTotal;
	}


	public int getSubTotal() {
		return SubTotal;
	}


	public void setSubTotal(int subTotal) {
		SubTotal = subTotal;
	}
	
	// Add method
	public void Add(ActionEvent e) {
		AddTotal=number1+number2;
		
	}
	// Subtract Method
	public void Subtract(ActionEvent e) {
		SubTotal = number1 - number2;
		
	}
	// Division Method
	public void DivisionTotal(ActionEvent e) {
		DivisionTotal = number1 / number2;
		
	}
	// Multiply Method
	
	public void MultiplyTotal(ActionEvent e) {
		MultiplyTotal = number1 * number2;
	}
}