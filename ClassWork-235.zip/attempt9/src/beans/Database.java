package beans;



import java.util.HashMap;
import java.util.Map.Entry;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

@ManagedBean
@ViewScoped
public class Database {
	
	HashMap<String,String> registeredUsers = new HashMap<String,String>();

	public void register(User user) 
	{
		registeredUsers.put(user.userName, user.passWord);
	}
	public boolean authenticate(User user) {
		
		if (registeredUsers == null) {
			return false;
		}
		else {
			return true;
		}
		
	}
	public HashMap<String, String> getRegisteredUsers() {
		return registeredUsers;
	}
	public void setRegisteredUsers(HashMap<String, String> registeredUsers) {
		this.registeredUsers = registeredUsers;
	}
	
	
	
}


	
