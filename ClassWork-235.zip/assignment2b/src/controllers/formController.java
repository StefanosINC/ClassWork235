package controllers;
import javax.faces.bean.ManagedBean;

import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import beans.User;
@ManagedBean
@ViewScoped
public class formController {
	public String onSubmit() 
	{
		FacesContext context = FacesContext.getCurrentInstance();
		User user = context.getApplication().evaluateExpressionGet(context,"#{user}", User.class);
		
		FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("user", user);
		return "NewFile.xhtml";
	}
	
	public String onSubmit(User user)
	{
	FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("user", user);
	return "NewFile.xhtml";
	}
	public String onFlash()
	{
		FacesContext context = FacesContext.getCurrentInstance();
		User user = context.getApplication().evaluateExpressionGet(context, "#{user}", User.class);
		
		FacesContext.getCurrentInstance().getExternalContext().getFlash().put("user", user);
		return "NewFile.xhtml?faces-redirect=true";
	}
	public String onFlash(User user) {
		FacesContext.getCurrentInstance().getExternalContext().getFlash().put("user", user);
		return "NewFile2.xhtml?faces-redirect=true";
	}
	
}
